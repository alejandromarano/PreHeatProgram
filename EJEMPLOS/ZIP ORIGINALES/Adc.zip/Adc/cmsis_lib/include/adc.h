/**
    @file adc.h
*/

#ifndef ADC_H
#define ADC_H

void    adc_inicializar(void);
int32_t adc_leer_cuentas(void);


#endif
